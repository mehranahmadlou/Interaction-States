% code for plotting Fig. 2 panels
% it requires installing Invivotools if you want to use ivt_graph,
% otherwise you can use MATLAB built-in functions

%%%%%%%%%%%%%%%%%%%%%%%
load MNOI_VGLUT2_MRN.mat
ivt_graph({(100/120)*Ctrl(:,1),(100/120)*supp(:,1),(100/120)*act(:,1)},[],'xticklabels',{'ctrl','supp','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Fraction of time (%)'); title('Fig. 2b Perseverative','FontSize',24)
ivt_graph({(100/120)*Ctrl(:,2),(100/120)*supp(:,2),(100/120)*act(:,2)},[],'xticklabels',{'ctrl','supp','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Fraction of time (%)'); title('Fig. 2b Exploratory','FontSize',24)
ivt_graph({(100/120)*Ctrl(:,3),(100/120)*supp(:,3),(100/120)*act(:,3)},[],'xticklabels',{'ctrl','supp','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Fraction of time (%)'); title('Fig. 2b Disengaged','FontSize',24)

color_groups = [0 114 178;0 158 115;213 94 0]/255;
figure;
p_mean = pie([median(Ctrl(:,1)),median(Ctrl(:,2)),median(Ctrl(:,3))]); legend({'Persevere','Explore','Disengage'},'FontSize',12);
p_mean(1).FaceColor = color_groups(1,:); p_mean(3).FaceColor = color_groups(2,:); p_mean(5).FaceColor = color_groups(3,:);
p_mean(2).FontSize = 12; p_mean(4).FontSize = 12; p_mean(6).FontSize = 12;
set(gcf,'color','white')
title('Fig. 2c Ctrl','FontSize',24) 

figure;
p_mean = pie([median(act(:,1)),median(act(:,2)),median(act(:,3))]); legend({'Persevere','Explore','Disengage'},'FontSize',12);
p_mean(1).FaceColor = color_groups(1,:); p_mean(3).FaceColor = color_groups(2,:); p_mean(5).FaceColor = color_groups(3,:);
p_mean(2).FontSize = 12; p_mean(4).FontSize = 12; p_mean(6).FontSize = 12;
set(gcf,'color','white')
title('Fig. 2c Act','FontSize',24) 

figure;
p_mean = pie([median(supp(:,1)),median(supp(:,2)),median(supp(:,3))]); legend({'Persevere','Explore','Disengage'},'FontSize',12);
p_mean(1).FaceColor = color_groups(1,:); p_mean(3).FaceColor = color_groups(2,:); p_mean(5).FaceColor = color_groups(3,:);
p_mean(2).FontSize = 12; p_mean(4).FontSize = 12; p_mean(6).FontSize = 12;
set(gcf,'color','white')
title('Fig. 2c Supp','FontSize',24) 

%%%%%%%%%%%%%%%%%%%%%%%
load States_activity_VGLUT2_MRN.mat
ivt_graph({Disengaged,Exploratory,Perseverative},[],'xticklabels',{'Disengaged','Exploratory','Perseverative'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Calcium activity (Z-scored)'); title('Fig. 2f','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%
load Entrance_Tmaze_VGLUT2_MRN.mat
ivt_graph({Ctrl,act},[],'xticklabels',{'ctrl','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Entrance'); title('Fig. 2h','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%
load Entrance_Reversal_VGLUT2_MRN.mat
ivt_graph({Ctrl,supp},[],'xticklabels',{'ctrl','supp'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Entrance'); title('Fig. 2j Reversal','FontSize',24)
