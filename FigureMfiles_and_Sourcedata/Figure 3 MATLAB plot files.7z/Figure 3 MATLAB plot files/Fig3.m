% code for plotting Fig. 3 panels
% it requires installing Invivotools if you want to use ivt_graph,
% otherwise you can use MATLAB built-in functions

load SelfStim_celltypes_MRN.mat
ivt_graph({Ctrl,VGLUT2_supp,VGLUT2_act,VGAT_supp,VGAT_act},[],'xticklabels',{'ctrl','V2supp','V2act','Vgatsupp','Vgatact'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Preference (%)'); title('Fig. 3b','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%
load TMTapproach_celltypes_MRN.mat
ivt_graph({Ctrl,VGLUT2_supp,VGLUT2_act,VGAT_supp,VGAT_act},[],'xticklabels',{'ctrl','V2supp','V2act','Vgatsupp','Vgatact'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Approach (N)'); title('Fig. 3d','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%
load TMTescape_celltypes_MRN.mat
ivt_graph({Ctrl,VGLUT2_supp,VGLUT2_act,VGAT_supp,VGAT_act},[],'xticklabels',{'ctrl','V2supp','V2act','Vgatsupp','Vgatact'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Escape prob. (%)'); title('Fig. 3e','FontSize',24)