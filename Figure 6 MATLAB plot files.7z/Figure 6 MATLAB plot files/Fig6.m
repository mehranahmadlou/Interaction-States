% code for plotting Fig. 6 panels
% it requires installing Invivotools if you want to use ivt_graph,
% otherwise you can use MATLAB built-in functions

load Pref_LHA_MRN.mat
ivt_graph({Pref_Ctrl,Pref_LHA_MRN_supp,Pref_LHA_MRN_act},[],'xticklabels',{'ctrl','supp','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Preference'); title('Fig. 6c','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%
load MNOI_LHA_MRN.mat
ivt_graph({(100/120)*Ctrl(:,1),(100/120)*supp(:,1),(100/120)*act(:,1)},[],'xticklabels',{'ctrl','supp','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Fraction of time (%)'); title('Fig. 6e Perseverative','FontSize',24)
ivt_graph({(100/120)*Ctrl(:,2),(100/120)*supp(:,2),(100/120)*act(:,2)},[],'xticklabels',{'ctrl','supp','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Fraction of time (%)'); title('Fig. 6e Exploratory','FontSize',24)
ivt_graph({(100/120)*Ctrl(:,3),(100/120)*supp(:,3),(100/120)*act(:,3)},[],'xticklabels',{'ctrl','supp','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Fraction of time (%)'); title('Fig. 6e Disengaged','FontSize',24)

color_groups = [0 114 178;0 158 115;213 94 0]/255;
figure;
p_mean = pie([median(Ctrl(:,1)),median(Ctrl(:,2)),median(Ctrl(:,3))]); legend({'Persevere','Explore','Disengage'},'FontSize',12);
p_mean(1).FaceColor = color_groups(1,:); p_mean(3).FaceColor = color_groups(2,:); p_mean(5).FaceColor = color_groups(3,:);
p_mean(2).FontSize = 12; p_mean(4).FontSize = 12; p_mean(6).FontSize = 12;
set(gcf,'color','white')
title('Fig. 6d Ctrl','FontSize',24) 

figure;
p_mean = pie([median(act(:,1)),median(act(:,2)),median(act(:,3))]); legend({'Persevere','Explore','Disengage'},'FontSize',12);
p_mean(1).FaceColor = color_groups(1,:); p_mean(3).FaceColor = color_groups(2,:); p_mean(5).FaceColor = color_groups(3,:);
p_mean(2).FontSize = 12; p_mean(4).FontSize = 12; p_mean(6).FontSize = 12;
set(gcf,'color','white')
title('Fig. 6d Act','FontSize',24) 

figure;
p_mean = pie([median(supp(:,1)),median(supp(:,2)),median(supp(:,3))]); legend({'Persevere','Explore','Disengage'},'FontSize',12);
p_mean(1).FaceColor = color_groups(1,:); p_mean(3).FaceColor = color_groups(2,:); p_mean(5).FaceColor = color_groups(3,:);
p_mean(2).FontSize = 12; p_mean(4).FontSize = 12; p_mean(6).FontSize = 12;
set(gcf,'color','white')
title('Fig. 6d Supp','FontSize',24) 

%%%%%%%%%%%%%%%%%%%%%%%
load Entrance_Reversal_LHA_MRN.mat
ivt_graph({Ctrl,act},[],'xticklabels',{'ctrl','act'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Entrance'); title('Fig. 6f Reversal','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%
load Entrance_Tmaze_LHA_MRN.mat
ivt_graph({Ctrl,act},[],'xticklabels',{'ctrl','supp'},'showpoints',1,'errorbars','sem','test','none')
ylabel('Entrance'); title('Fig. 6g Reversal','FontSize',24)

%%%%%%%%%%%%%%%%%%%%%%%
load LHA_sigs_bZscore.mat
% colors
color_sig = [0.47,0.67,0.19;0.00,0.45,0.74;0.70 0.42 0.00;0.59,0.12,0.12];

mean_psth_beh = mean(sigs_bZscore);
sem_psth_beh = std(sigs_bZscore);

figure;hold on;
x = 1/130:1/130:length(mean_psth_beh)/130;
y1 = mean_psth_beh-sem_psth_beh;
y2 = mean_psth_beh+sem_psth_beh;
P = patch([x fliplr(x)], [y1 fliplr(y2)],'g','FaceAlpha',0.3,'EdgeAlpha',0)
P.FaceColor = color_sig(1,:);
plot(1/130:1/130:length(mean_psth_beh)/130,mean_psth_beh,'color',color_sig(1,:),'LineWidth',3);
% alpha(0.3)
xlim([0 9]);ylabel('Calcuim activity (Z-score)','FontSize',20);
hold on;
plot([3 3],[-5 5],'k--')
plot([0 12],[0 0],'k--')

box off
set(gcf,'color','white')
xticks([-3 0 3 6])
ax = gca;
ax.XTick = 0:3:9;
xticklabels({-3:3:6})
xlim([0 8])
% ylim([-3 3])
hold off
% xlim([0 12]);

xlabel('Time (s)','FontSize',20)
title('Fig. 6i VGAT:GCaMP','FontSize',24)
set(gcf,'renderer','Painters')
